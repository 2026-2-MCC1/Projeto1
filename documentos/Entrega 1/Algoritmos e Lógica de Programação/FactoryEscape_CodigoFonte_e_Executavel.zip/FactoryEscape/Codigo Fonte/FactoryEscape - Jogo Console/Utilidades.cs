﻿namespace Game;

public static class Utilidades
{

    // velocidades da digitação (ms por caractere) e pausa padrão
    public const int Rapido = 45;
    public const int Normal = 75;
    public const int Pausa = 900;

    // efeito de digitação letra por letra. apertar qualquer tecla pula a animação.
    public static void EfeitoDigitado(string texto, int delay)
    {
        foreach (char c in texto)
        {
            Console.Write(c);
            if (!TeclaPressionada())
                Thread.Sleep(delay);
        }
        Console.WriteLine();
        LimparBuffer();
    }

    // narração: digitação rápida
    public static void Narrar(string texto)
    {
        EfeitoDigitado(texto, Rapido);
    }

    // fala do personagem: digitação mais lenta e colorida
    public static void Fala(string nome, string mensagem)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        EfeitoDigitado($"\n{nome}: {mensagem}", Normal);
        Console.ResetColor();
    }

    // pausa / suspense
    public static void Pensando(int tempo)
    {
        Thread.Sleep(tempo);
    }

    // exibe texto colorido
    public static void TextoColorido(string texto, ConsoleColor cor)
    {
        Console.ForegroundColor = cor;
        Console.WriteLine(texto);
        Console.ResetColor();
    }

    // lê um número entre min e max sem quebrar se o jogador digitar letras ou nada
    public static int LerOpcao(int min, int max)
    {
        while (true)
        {
            Console.Write("-> ");
            string? entrada = Console.ReadLine();

            if (int.TryParse(entrada, out int valor) && valor >= min && valor <= max)
                return valor;

            TextoColorido($"Opção inválida! Digite um número de {min} a {max}.", ConsoleColor.Red);
        }
    }

    // lê texto tratando null, espaços nas pontas e maiúsculas/minúsculas
    public static string LerTexto()
    {
        return (Console.ReadLine() ?? "").Trim().ToUpper();
    }

    // dá tempo para o jogador ler antes de limpar a tela, muito importante para não pular mensagens sem ter lido
    public static void AguardarTecla()
    {
        Console.WriteLine("\n[Pressione qualquer tecla para continuar]");
        try
        {
            Console.ReadKey(true);
        }
        catch (InvalidOperationException)
        {
            Console.ReadLine(); // alguns terminais não suportam ReadKey
        }
        Console.Clear();
    }

    // contagem 3, 2, 1 seguida de game over
    public static void ContagemRegressiva(string aviso, string motivo)
    {
        Pensando(200);
        TextoColorido($"\n{aviso}", ConsoleColor.Red);

        for (int i = 3; i >= 1; i--)
        {
            Pensando(700);
            TextoColorido(i.ToString(), ConsoleColor.Red); // como ele vem em int, precisa converter para string pq o metodo TextoColorido exige string
        }

        GameOver(motivo);
    }

    public static void GameOver(string motivo)
    {
        Pensando(Pausa);
        TextoColorido($"\n[GAME OVER] {motivo}", ConsoleColor.Red);
        AguardarTecla();
        Environment.Exit(0);
    }

    private static bool TeclaPressionada()
    {
        try
        {
            return Console.KeyAvailable;
        }
        catch (InvalidOperationException)
        {
            return false; // terminais sem suporte (ex.: console de depuração)
        }
    }

    // descarta teclas apertadas para pular a animação, para não "vazarem" na próxima leitura
    private static void LimparBuffer()
    {
        while (TeclaPressionada())
            Console.ReadKey(true);
    }
}