using static Game.Utilidades;

namespace Game;

public static class Cenas
{
    // inicio
    public static Jogador? Introducao()
    {
        TextoColorido("!-- Escape Room - ARCOR --!", ConsoleColor.Cyan);
        Console.WriteLine(logoTipo.logo);
        Pensando(400);

        string nome = "";
        while (nome == "")
        {
            Console.WriteLine("Insira o nome do personagem:");
            nome = (Console.ReadLine() ?? "").Trim();
        }
        Console.Clear();

        TextoColorido($"\nBem-vindo(a), {nome}!\n", ConsoleColor.Cyan);
        Console.WriteLine("Este jogo é uma aventura de mistério e suspense.");
        Console.WriteLine("Lembre-se: você perde energia ao tomar decisões erradas. Se ela chegar a zero, é fim de jogo.");
        Console.WriteLine("Dica: aperte qualquer tecla durante um texto para pular a animação.");
        Console.WriteLine(logoTipo.logo);


        Console.WriteLine("\nDeseja iniciar o jogo? (S/N)");
        string decisao = LerTexto(); // ja aplica o trim e upper dentro do método
        while (decisao != "S" && decisao != "N")
        {
            Console.WriteLine("Resposta inválida. Digite S ou N:");
            decisao = LerTexto();
        }

        if (decisao == "N")
        {
            TextoColorido("Você decide não iniciar o jogo.", ConsoleColor.Red);
            Pensando(200);
            return null;
        }

        Console.Clear();
        return new Jogador(nome);
    }

    // cena laboratório
    public static void Laboratorio(Jogador jogador)
    {
        Pensando(Pausa);
        Narrar("Sexta-feira à noite. O laboratório de TI está silencioso, com exceção do zumbido constante " +
            "das torres de servidores e das ventoinhas dos PCs.\n\n" +
            "Você ficou até mais tarde para terminar aquele projeto de automação que a Arcor encomendou para o laboratório.");

        Pensando(400);
        Narrar("\nO código finalmente compilou, os comandos estavam rodando bem e... o cansaço bateu forte. " +
            "Você encostou a cabeça na bancada por um segundo para descansar os olhos.");

        Pensando(Pausa);
        Narrar("\nDe repente...");
        Pensando(1200);
        Console.Clear();

        Pensando(Pausa);
        Fala(jogador.Nome, Cenario.mensagensLab[0]);

        Pensando(Pausa);
        Narrar("\nVocê se levanta da cadeira com dificuldade, sentindo o corpo rígido depois de tantas horas debruçado na bancada. " +
            "A única fonte de luz na sala vem do monitor principal, que exibe em loop o logotipo da Arcor e uma mensagem de erro do sistema:");
        TextoColorido("\n[ERRO 0x5: REDE CORPORATIVA ISOLADA]", ConsoleColor.Red);

        Pensando(Pausa);
        Narrar("\nVocê corre até a porta principal de saída. Ela só abre com um cartão de acesso magnético.");
        AguardarTecla();

        bool terminalLiberado = false;

        while (!terminalLiberado)
        {
            Console.WriteLine("O que você deseja fazer?");
            Console.WriteLine("1. Procurar o cartão no bolso da camisa");
            Console.WriteLine("2. Procurar o cartão no bolso da calça");
            Console.WriteLine("3. Ir até o terminal da bancada");

            int escolha = LerOpcao(1, 3);
            Pensando(Pausa);

            if (escolha == 1)
            {
                Narrar("\nVocê procura no bolso da camisa, mas não encontra nada.");
                Fala(jogador.Nome, Cenario.mensagensLab[1]);
                jogador.PerderEnergia(10);
            }
            else if (escolha == 2)
            {
                if (!jogador.TemCartao)
                {
                    Narrar("\nVocê encontra o cartão de acesso magnético no bolso da calça.");
                    jogador.TemCartao = true;
                }

                Narrar("\nVocê passa o cartão no leitor da porta... A luz vermelha pisca e um som estridente ecoa:");
                TextoColorido("\n'Acesso negado. Protocolo de segurança ativado.'", ConsoleColor.Red);
                Fala(jogador.Nome, Cenario.mensagensLab[2]);
                jogador.PerderEnergia(10);
            }
            else // escolha == 3
            {
                if (jogador.TemCartao)
                {
                    Narrar("\nSem saída pela porta, você volta os olhos para a bancada. O terminal da Arcor continua piscando, " +
                        "como se estivesse esperando um comando ou tentando resolver um processo travado.");
                    terminalLiberado = true;
                }
                else
                {
                    Narrar("\nVocê vai até a bancada. Ao lado da tela, um leitor de crachá pisca, esperando uma identificação.");
                    Fala(jogador.Nome, Cenario.mensagensLab[7]);
                }
            }

            AguardarTecla();
        }
    }

    // cena terminal
    public static void Terminal(Jogador jogador)
    {
        Narrar("Você aproxima o crachá do leitor lateral do computador da bancada.");
        Pensando(Pausa);
        Narrar("\nUm bipe soa, e o monitor troca a tela preta de erro por uma interface de linha de comando corporativa da Arcor.");
        Pensando(Pausa);
        TextoColorido("\n[SISTEMA DE SEGURANÇA - SETOR TI]\n\nAVISO: Protocolo de bloqueio ativo. " +
            "Insira a chave de criptografia para liberar o travamento.", ConsoleColor.Red);

        for (int tentativa = 1; tentativa <= Cenario.MaxTentativas; tentativa++)
        {
            Pensando(Pausa);
            Console.WriteLine("\nDica: o nome de 5 letras que batiza nossos servidores centrais e o sistema de dados.");
            Console.Write("root@arcor-lab:~# inserir_senha -> ");

            if (LerTexto() == Cenario.desafios[0])
            {
                Pensando(Pausa);
                TextoColorido("\n[SUCESSO] Chave validada!", ConsoleColor.Green);
                Pensando(Pausa);
                Narrar("\nOs LEDs da porta principal passam de vermelho para verde, " +
                    "e o estalo seco da tranca magnética se abrindo ecoa pela sala vazia.");
                AguardarTecla();
                return;
            }

            int restantes = Cenario.MaxTentativas - tentativa;
            if (restantes == 0)
            {
                ContagemRegressiva("[ACESSO NEGADO] Credencial inválida. Sala se autodestruindo em...",
                    "Você falhou em desbloquear a porta a tempo.");
            }

            Pensando(Pausa);
            TextoColorido("\n[ACESSO NEGADO] Credencial inválida. Tente novamente.", ConsoleColor.Red);
            Console.WriteLine($"Tentativas restantes: {restantes}");
            jogador.PerderEnergia(10);
        }
    }

    // cena corredor
    public static void Corredor(Jogador jogador)
    {
        Narrar("Assim que a porta se abre, um silêncio pesado toma conta do corredor. " +
            "Você dá alguns passos para fora, aliviado com o ar fresco que parecia faltar no laboratório.");
        Pensando(Pausa);
        Narrar("\nDe repente, um estalo ecoa pelo teto. Todas as lâmpadas do corredor piscam violentamente duas vezes... e apagam de vez. " +
            "A escuridão é total, cortada apenas pelas luzes de emergência distantes.");

        Pensando(Pausa);
        Fala(jogador.Nome, Cenario.mensagensLab[3]);
        Pensando(Pausa);

        Console.WriteLine("\nComo você deseja avançar pelo corredor escuro?");
        Console.WriteLine("1. Caminhar tateando a parede (Cauteloso)");
        Console.WriteLine("2. Tentar usar a lanterna do celular (Mais rápido)");
        Console.WriteLine("3. Ir correndo às cegas (Arriscado)");

        int escolha = LerOpcao(1, 3);
        Pensando(Pausa);

        if (escolha == 1)
        {
            Narrar("\nVocê decide não arriscar e estende a mão, encostando os dedos no concreto gelado da parede. " +
                "Com passos curtos e arrastados, você avança com paciência até encontrar o painel.");
        }
        else if (escolha == 2)
        {
            Narrar("\nVocê tira o celular do bolso e aperta o botão lateral para acender a lanterna. " +
                "Mas a tela pisca uma única vez com o ícone de bateria descarregada... e apaga de vez.");
            Pensando(Pausa);
            Fala(jogador.Nome, Cenario.mensagensLab[4]);
            Pensando(Pausa);
            Narrar("\nSem luz, você é obrigado a tatear a parede às cegas pelo resto do caminho até o painel.");
            jogador.PerderEnergia(15);
        }
        else // escolha == 3
        {
            Narrar("\nA pressa é tanta que você dispara correndo pelo corredor escuro. " +
                "Erro fatal: seu pé enrosca em um cabo de rede e você vai ao chão, batendo o ombro com força.");
            Pensando(Pausa);
            Fala(jogador.Nome, Cenario.mensagensLab[5]);
            jogador.PerderEnergia(30);
        }

        AguardarTecla();
    }

    // cena fusível
    public static void Fusivel(Jogador jogador)
    {
        Narrar("Tateando a parede no escuro, você finalmente alcança a caixa de força principal da Arcor. " +
            "Ao forçar a tampa metálica, o cheiro de ozônio toma conta do ar. O fusível principal queimou por causa de uma sobrecarga.");
        Pensando(Pausa);
        Narrar("\nVocê procura a etiqueta de especificações na lateral da caixa, mas ela está chamuscada. " +
            "O campo do fusível ficou ilegível. Só dá para ler:");
        MostrarEtiqueta();

        Pensando(Pausa);
        Narrar("\nVocê se lembra da aula de circuitos: a corrente do fusível é a potência dividida pela tensão.");
        AguardarTecla();

        for (int tentativa = 1; tentativa <= Cenario.MaxTentativas; tentativa++)
        {
            MostrarEtiqueta();
            Console.WriteLine("\nVocê olha para as peças de reposição espalhadas na caixa. Qual fusível você coloca no painel?");
            Console.WriteLine("1. 10A");
            Console.WriteLine("2. 15A");
            Console.WriteLine("3. 20A");
            Console.WriteLine("4. 25A");
            Console.Write("root@arcor-corredor:~# selecionar_fusivel -> ");

            // aceita o número da opção ("2"), o código ("15A") ou só o valor ("15")
            string resposta = LerTexto().Replace(" ", "");
            bool correto = resposta == Cenario.desafios[1]
                        || resposta == Cenario.desafios[2]
                        || resposta + "A" == Cenario.desafios[2];

            if (correto)
            {
                Pensando(Pausa);
                TextoColorido("\n[SUCESSO] Fusível encaixado!", ConsoleColor.Green);
                Pensando(Pausa);
                Narrar("\nUm estalo soa, as lâmpadas do teto piscam e voltam a brilhar com força total. O corredor está iluminado de novo!");
                AguardarTecla();
                return;
            }

            int restantes = Cenario.MaxTentativas - tentativa;
            if (restantes == 0)
            {
                ContagemRegressiva("[ALERTA] Sobrecarga crítica no quadro! Desligamento de emergência em...",
                    "Você falhou em encaixar o fusível correto a tempo.");
            }

            Pensando(Pausa);
            TextoColorido("\n[ALERTA] Especificação incompatível! Faíscas saltam do painel e o fusível queima na hora.", ConsoleColor.Red);
            Console.WriteLine($"Tentativas restantes: {restantes}");
            jogador.PerderEnergia(10);

            Pensando(Pausa);
            Fala(jogador.Nome, Cenario.mensagensLab[6]);
            AguardarTecla();
        }
    }

    private static void MostrarEtiqueta()
    {
        TextoColorido(
            "\n  +--------------------------------+" +
            "\n  |  ARCOR - SETOR TI - QUADRO 03  |" +
            "\n  |  Potência total:  3300 W       |" +
            "\n  |  Tensão da rede:  220 V        |" +
            "\n  |  Fusível:  ##A  (ilegível)     |" +
            "\n  +--------------------------------+", ConsoleColor.Green);
    }

    // fase final
    public static void Final(Jogador jogador)
    {
        Narrar("Com o corredor iluminado, você segue até a saída de emergência. " +
            "A porta corta-fogo cede com um empurrão, e o ar frio da noite bate no seu rosto.");
        Pensando(Pausa);
        Fala(jogador.Nome, Cenario.mensagensLab[8]);

        Pensando(Pausa);
        TextoColorido($"\n[FIM] Parabéns, {jogador.Nome}! Você escapou da Arcor com {jogador.Energia} de energia.", ConsoleColor.Green);
        Console.WriteLine(logoTipo.logo);
        AguardarTecla();
    }
}