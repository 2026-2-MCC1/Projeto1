﻿namespace Game;

public static class Cenario
{
    public const int MaxTentativas = 3;

    public static string[] mensagensLab = new string[]
    {
        "Aaah, o que aconteceu? Por que está tudo tão escuro? Cadê o pessoal?",          // [0] - acordando no laboratório
        "Nada aqui.",                                                                    // [1] - bolso da camisa vazio
        "A porta está trancada por fora. Forçar não vai adiantar.",                      // [2] - cartão recusado na porta
        "Mas o que é isso... A energia caiu no prédio todo? Preciso achar a caixa de distribuição antes que o sistema de segurança bloqueie os andares superiores.", // [3] - apagão no corredor
        "Não acredito... Justo agora a bateria me abandona?",                            // [4] - celular sem bateria (opção 2)
        "Ai... Que droga! Correr no escuro foi uma péssima ideia.",                      // [5] - queda ao correr (opção 3)
        "Droga, esse não era o modelo certo. Preciso fazer essa conta direito.",        // [6] - fusível errado
        "O terminal pede um crachá... Preciso achar o meu primeiro.",                   // [7] - terminal sem cartão
        "Finalmente... Segunda-feira eu conto isso pro pessoal. O Savino nunca vai acreditar." // [8] - final
    };

    // [0] senha do terminal, [1] número da opção do fusível correto, [2] código do fusível correto
    public static string[] desafios = new string[3] { "ARCOR", "2", "15A" };
}