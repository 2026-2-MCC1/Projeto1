namespace Game;

public class Jogador
{
    public string Nome { get; }
    public int Energia { get; private set; } = 100;
    public bool TemCartao { get; set; } = false; 

    public Jogador(string nome)
    {
        Nome = nome;
    }

    // desconta energia e encerra o jogo se ela chegar a zero
    public void PerderEnergia(int quantidade)
    {
        Energia = Math.Max(0, Energia - quantidade);

        if (Energia == 0)
        {
            Utilidades.TextoColorido("\nSua energia acabou! Você desaba de exaustão no chão frio da Arcor...", ConsoleColor.Red);
            Utilidades.GameOver("Você ficou sem energia.");
        }

        Utilidades.TextoColorido($"\nSua energia caiu! Energia restante: {Energia}", ConsoleColor.Yellow);
    }
}