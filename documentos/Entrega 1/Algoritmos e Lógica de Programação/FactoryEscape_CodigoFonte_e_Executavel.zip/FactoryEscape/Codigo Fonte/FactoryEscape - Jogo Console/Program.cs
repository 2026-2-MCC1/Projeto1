﻿namespace Game;

class Program
{
    static void Main(string[] args)
    {
        // garante que acentos e caracteres especiais apareçam certo no console do windows, toda hora bugava isso
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Jogador? jogador = Cenas.Introducao();
        if (jogador == null)
            return;

        Cenas.Laboratorio(jogador);
        Cenas.Terminal(jogador);
        Cenas.Corredor(jogador);
        Cenas.Fusivel(jogador);
        Cenas.Final(jogador);
    }
}